import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertWellnessEntrySchema, 
  insertInjurySchema,
  insertUserPreferencesSchema,
  type WellnessEntry,
  type Injury 
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create wellness entry
  app.post("/api/wellness-entries", async (req, res) => {
    try {
      const validatedData = insertWellnessEntrySchema.parse(req.body);
      const entry = await storage.createWellnessEntry(validatedData);
      res.json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get recent wellness entries
  app.get("/api/wellness-entries", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const entries = await storage.getWellnessEntries(limit);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get wellness entries in date range
  app.get("/api/wellness-entries/range", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      
      if (!startDate || !endDate) {
        return res.status(400).json({ message: "startDate and endDate are required" });
      }

      const start = new Date(startDate as string);
      const end = new Date(endDate as string);
      
      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return res.status(400).json({ message: "Invalid date format" });
      }

      const entries = await storage.getWellnessEntriesInDateRange(start, end);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Export wellness entries as CSV
  app.get("/api/wellness-entries/export", async (req, res) => {
    try {
      const entries = await storage.getWellnessEntries();
      
      // Create CSV content
      const headers = ['Date', 'Sleep Hours', 'Fatigue Level', 'RPE', 'Session Type', 'Injury Status'];
      const csvContent = [
        headers.join(','),
        ...entries.map(entry => [
          new Date(entry.timestamp).toLocaleDateString(),
          entry.sleepHours,
          entry.fatigueLevel,
          entry.rpe,
          entry.sessionType,
          entry.injuryStatus
        ].join(','))
      ].join('\n');

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename=wellness-data.csv');
      res.send(csvContent);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get dashboard stats
  app.get("/api/wellness-entries/stats", async (req, res) => {
    try {
      const entries = await storage.getWellnessEntries();
      
      if (entries.length === 0) {
        return res.json({
          avgSleep: 0,
          avgFatigue: 0,
          avgRpe: 0,
          totalTrainingLoad: 0,
          weeklyStats: []
        });
      }

      const avgSleep = entries.reduce((sum, entry) => sum + parseFloat(entry.sleepHours), 0) / entries.length;
      const avgFatigue = entries.reduce((sum, entry) => sum + entry.fatigueLevel, 0) / entries.length;
      const avgRpe = entries.reduce((sum, entry) => sum + entry.rpe, 0) / entries.length;
      
      // Calculate training load (RPE * estimated session duration)
      const sessionDurations: Record<string, number> = { none: 0, pitch: 90, gym: 60, match: 120 };
      const totalTrainingLoad = entries.reduce((sum, entry) => {
        const duration = sessionDurations[entry.sessionType] || 0;
        return sum + (entry.rpe * duration);
      }, 0);

      res.json({
        avgSleep: Math.round(avgSleep * 10) / 10,
        avgFatigue: Math.round(avgFatigue * 10) / 10,
        avgRpe: Math.round(avgRpe * 10) / 10,
        totalTrainingLoad,
        weeklyStats: entries.slice(0, 7)
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get last entry for auto-fill
  app.get("/api/wellness-entries/last", async (req, res) => {
    try {
      const lastEntry = await storage.getLastEntry();
      res.json(lastEntry || null);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Weekly comparison analytics
  app.get("/api/analytics/weekly-comparison", async (req, res) => {
    try {
      const comparison = await storage.getWeeklyComparison();
      res.json(comparison);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Team stats
  app.get("/api/team/stats", async (req, res) => {
    try {
      const teamStats = await storage.getTeamStats();
      res.json(teamStats);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Energy score calculation
  app.get("/api/analytics/energy-score", async (req, res) => {
    try {
      const lastEntry = await storage.getLastEntry();
      if (!lastEntry) {
        return res.json({ score: null, status: "No data available" });
      }

      // Calculate energy score (0-100) based on sleep, fatigue, and RPE
      const sleepScore = Math.min(parseFloat(lastEntry.sleepHours) / 8, 1) * 35; // 35% weight
      const fatigueScore = (6 - lastEntry.fatigueLevel) / 5 * 35; // 35% weight (inverted)
      const rpeScore = (11 - lastEntry.rpe) / 10 * 30; // 30% weight (inverted)
      
      const totalScore = Math.round(sleepScore + fatigueScore + rpeScore);
      
      let status = "Poor";
      if (totalScore >= 80) status = "Excellent";
      else if (totalScore >= 65) status = "Good";
      else if (totalScore >= 50) status = "Fair";

      res.json({ 
        score: totalScore, 
        status,
        breakdown: {
          sleep: Math.round(sleepScore),
          fatigue: Math.round(fatigueScore),
          rpe: Math.round(rpeScore)
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Injury tracking routes
  app.post("/api/injuries", async (req, res) => {
    try {
      const validatedData = insertInjurySchema.parse({
        ...req.body,
        dateOccurred: new Date(req.body.dateOccurred),
        dateResolved: req.body.dateResolved ? new Date(req.body.dateResolved) : undefined,
      });
      const injury = await storage.createInjury(validatedData);
      res.json(injury);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.get("/api/injuries", async (req, res) => {
    try {
      const activeOnly = req.query.active === "true";
      const injuries = await storage.getInjuries(activeOnly);
      res.json(injuries);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/injuries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      if (updates.dateResolved) {
        updates.dateResolved = new Date(updates.dateResolved);
      }
      const injury = await storage.updateInjury(id, updates);
      res.json(injury);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // User preferences routes
  app.get("/api/preferences", async (req, res) => {
    try {
      const preferences = await storage.getUserPreferences();
      res.json(preferences);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/preferences", async (req, res) => {
    try {
      const validatedData = insertUserPreferencesSchema.partial().parse(req.body);
      const preferences = await storage.updateUserPreferences(validatedData);
      res.json(preferences);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Pattern analysis
  app.get("/api/analytics/patterns", async (req, res) => {
    try {
      const entries = await storage.getWellnessEntries(30); // Last 30 entries
      const patterns = [];

      if (entries.length >= 7) {
        // Fatigue after matches
        const matchDays = entries.filter(e => e.sessionType === "match");
        if (matchDays.length >= 2) {
          const avgFatigueAfterMatch = matchDays.reduce((sum, match) => {
            const nextDay = entries.find(e => {
              const matchDate = new Date(match.timestamp);
              const entryDate = new Date(e.timestamp);
              return entryDate.getTime() > matchDate.getTime() && 
                     entryDate.getTime() <= matchDate.getTime() + (24 * 60 * 60 * 1000);
            });
            return sum + (nextDay ? nextDay.fatigueLevel : 3);
          }, 0) / matchDays.length;

          if (avgFatigueAfterMatch >= 3.5) {
            patterns.push({
              type: "fatigue_pattern",
              title: "Post-Match Fatigue",
              description: `Fatigue tends to rise after match days (avg: ${avgFatigueAfterMatch.toFixed(1)}/5)`,
              severity: avgFatigueAfterMatch >= 4 ? "high" : "medium"
            });
          }
        }

        // Sleep before matches
        const sleepBeforeMatches = matchDays.map(match => {
          const dayBefore = entries.find(e => {
            const matchDate = new Date(match.timestamp);
            const entryDate = new Date(e.timestamp);
            return entryDate.getTime() < matchDate.getTime() && 
                   entryDate.getTime() >= matchDate.getTime() - (24 * 60 * 60 * 1000);
          });
          return dayBefore ? parseFloat(dayBefore.sleepHours) : 8;
        });

        if (sleepBeforeMatches.length > 0) {
          const avgSleepBeforeMatch = sleepBeforeMatches.reduce((a, b) => a + b, 0) / sleepBeforeMatches.length;
          if (avgSleepBeforeMatch < 7) {
            patterns.push({
              type: "sleep_pattern",
              title: "Pre-Match Sleep",
              description: `Sleep is low before matches (avg: ${avgSleepBeforeMatch.toFixed(1)}h)`,
              severity: "medium"
            });
          }
        }
      }

      res.json(patterns);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Recovery recommendations
  app.get("/api/analytics/recommendations", async (req, res) => {
    try {
      const recentEntries = await storage.getWellnessEntries(3);
      const recommendations = [];

      if (recentEntries.length >= 3) {
        const avgFatigue = recentEntries.reduce((sum, e) => sum + e.fatigueLevel, 0) / recentEntries.length;
        const avgSleep = recentEntries.reduce((sum, e) => sum + parseFloat(e.sleepHours), 0) / recentEntries.length;
        const highIntensityDays = recentEntries.filter(e => e.rpe >= 7).length;

        if (avgFatigue >= 4) {
          recommendations.push({
            type: "rest",
            title: "Consider Rest Day",
            description: "High fatigue for multiple days. Take a rest day or light training.",
            priority: "high"
          });
        }

        if (avgSleep < 7) {
          recommendations.push({
            type: "sleep",
            title: "Improve Sleep",
            description: "Get to bed earlier tonight. Aim for 8+ hours of sleep.",
            priority: "medium"
          });
        }

        if (highIntensityDays >= 2) {
          recommendations.push({
            type: "recovery",
            title: "Active Recovery",
            description: "Include light recovery sessions and focus on hydration.",
            priority: "medium"
          });
        }
      }

      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
