import { 
  wellnessEntries, 
  type WellnessEntry, 
  type InsertWellnessEntry,
  type Injury,
  type InsertInjury,
  type UserPreferences,
  type InsertUserPreferences
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<any | undefined>;
  getUserByUsername(username: string): Promise<any | undefined>;
  createUser(user: any): Promise<any>;
  
  // Wellness entries methods
  createWellnessEntry(entry: InsertWellnessEntry): Promise<WellnessEntry>;
  getWellnessEntries(limit?: number): Promise<WellnessEntry[]>;
  getWellnessEntriesInDateRange(startDate: Date, endDate: Date): Promise<WellnessEntry[]>;
  getRecentWellnessEntries(limit: number): Promise<WellnessEntry[]>;
  getLastEntry(): Promise<WellnessEntry | undefined>;
  
  // Injury methods
  createInjury(injury: InsertInjury): Promise<Injury>;
  getInjuries(activeOnly?: boolean): Promise<Injury[]>;
  updateInjury(id: number, updates: Partial<Injury>): Promise<Injury>;
  
  // User preferences methods
  getUserPreferences(): Promise<UserPreferences>;
  updateUserPreferences(preferences: Partial<InsertUserPreferences>): Promise<UserPreferences>;
  
  // Analytics methods
  getWeeklyComparison(): Promise<{
    thisWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
    lastWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
  }>;
  
  // Team methods (dummy data for now)
  getTeamStats(): Promise<{
    memberCount: number;
    averages: { sleep: number; fatigue: number; rpe: number };
    yourRank: { sleep: number; fatigue: number; rpe: number };
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, any>;
  private wellnessEntries: Map<number, WellnessEntry>;
  private injuries: Map<number, Injury>;
  private userPreferences: UserPreferences;
  currentUserId: number;
  currentWellnessId: number;
  currentInjuryId: number;

  constructor() {
    this.users = new Map();
    this.wellnessEntries = new Map();
    this.injuries = new Map();
    this.currentUserId = 1;
    this.currentWellnessId = 1;
    this.currentInjuryId = 1;
    
    // Default user preferences
    this.userPreferences = {
      id: 1,
      reminderTime: "20:00",
      enableReminders: true,
      autoFillEnabled: true,
      teamId: "team-gaa-001",
      coachMode: false,
      timestamp: new Date(),
    };
  }

  async getUser(id: number): Promise<any | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<any | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: any): Promise<any> {
    const id = this.currentUserId++;
    const user = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createWellnessEntry(insertEntry: InsertWellnessEntry): Promise<WellnessEntry> {
    const id = this.currentWellnessId++;
    const entry: WellnessEntry = {
      ...insertEntry,
      id,
      sleepHours: insertEntry.sleepHours.toString(),
      timestamp: new Date(),
    };
    this.wellnessEntries.set(id, entry);
    return entry;
  }

  async getWellnessEntries(limit?: number): Promise<WellnessEntry[]> {
    const entries = Array.from(this.wellnessEntries.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    return limit ? entries.slice(0, limit) : entries;
  }

  async getWellnessEntriesInDateRange(startDate: Date, endDate: Date): Promise<WellnessEntry[]> {
    return Array.from(this.wellnessEntries.values()).filter(entry => {
      const entryDate = new Date(entry.timestamp);
      return entryDate >= startDate && entryDate <= endDate;
    }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getRecentWellnessEntries(limit: number): Promise<WellnessEntry[]> {
    return this.getWellnessEntries(limit);
  }

  async getLastEntry(): Promise<WellnessEntry | undefined> {
    const entries = await this.getWellnessEntries(1);
    return entries.length > 0 ? entries[0] : undefined;
  }

  // Injury methods
  async createInjury(insertInjury: InsertInjury): Promise<Injury> {
    const id = this.currentInjuryId++;
    const injury: Injury = {
      ...insertInjury,
      id,
      description: insertInjury.description || null,
      dateResolved: insertInjury.dateResolved || null,
      timestamp: new Date(),
    };
    this.injuries.set(id, injury);
    return injury;
  }

  async getInjuries(activeOnly: boolean = false): Promise<Injury[]> {
    const injuries = Array.from(this.injuries.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    return activeOnly ? injuries.filter(i => i.isActive) : injuries;
  }

  async updateInjury(id: number, updates: Partial<Injury>): Promise<Injury> {
    const injury = this.injuries.get(id);
    if (!injury) throw new Error("Injury not found");
    
    const updatedInjury = { ...injury, ...updates };
    this.injuries.set(id, updatedInjury);
    return updatedInjury;
  }

  // User preferences methods
  async getUserPreferences(): Promise<UserPreferences> {
    return this.userPreferences;
  }

  async updateUserPreferences(preferences: Partial<InsertUserPreferences>): Promise<UserPreferences> {
    this.userPreferences = { ...this.userPreferences, ...preferences };
    return this.userPreferences;
  }

  // Analytics methods
  async getWeeklyComparison(): Promise<{
    thisWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
    lastWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
  }> {
    const now = new Date();
    const startOfThisWeek = new Date(now);
    startOfThisWeek.setDate(now.getDate() - now.getDay());
    startOfThisWeek.setHours(0, 0, 0, 0);

    const startOfLastWeek = new Date(startOfThisWeek);
    startOfLastWeek.setDate(startOfThisWeek.getDate() - 7);

    const endOfLastWeek = new Date(startOfThisWeek);
    endOfLastWeek.setMilliseconds(-1);

    const thisWeekEntries = await this.getWellnessEntriesInDateRange(startOfThisWeek, now);
    const lastWeekEntries = await this.getWellnessEntriesInDateRange(startOfLastWeek, endOfLastWeek);

    const calculateStats = (entries: WellnessEntry[]) => {
      if (entries.length === 0) return { totalLoad: 0, avgSleep: 0, avgFatigue: 0 };
      
      const sessionDurations: Record<string, number> = { none: 0, pitch: 90, gym: 60, match: 120 };
      const totalLoad = entries.reduce((sum, entry) => {
        const duration = sessionDurations[entry.sessionType] || 0;
        return sum + (entry.rpe * duration);
      }, 0);
      
      const avgSleep = entries.reduce((sum, entry) => sum + parseFloat(entry.sleepHours), 0) / entries.length;
      const avgFatigue = entries.reduce((sum, entry) => sum + entry.fatigueLevel, 0) / entries.length;
      
      return { totalLoad, avgSleep, avgFatigue };
    };

    return {
      thisWeek: calculateStats(thisWeekEntries),
      lastWeek: calculateStats(lastWeekEntries),
    };
  }

  // Team methods (dummy data)
  async getTeamStats(): Promise<{
    memberCount: number;
    averages: { sleep: number; fatigue: number; rpe: number };
    yourRank: { sleep: number; fatigue: number; rpe: number };
  }> {
    const entries = await this.getWellnessEntries();
    const yourAvgSleep = entries.length > 0 ? 
      entries.reduce((sum, entry) => sum + parseFloat(entry.sleepHours), 0) / entries.length : 7.5;
    const yourAvgFatigue = entries.length > 0 ? 
      entries.reduce((sum, entry) => sum + entry.fatigueLevel, 0) / entries.length : 3;
    const yourAvgRpe = entries.length > 0 ? 
      entries.reduce((sum, entry) => sum + entry.rpe, 0) / entries.length : 6;

    // Simulated team averages
    return {
      memberCount: 25,
      averages: { sleep: 7.2, fatigue: 3.1, rpe: 5.8 },
      yourRank: {
        sleep: Math.round((yourAvgSleep / 7.2) * 100),
        fatigue: Math.round(((6 - yourAvgFatigue) / (6 - 3.1)) * 100), // Inverted for fatigue
        rpe: Math.round((yourAvgRpe / 5.8) * 100),
      },
    };
  }
}

export const storage = new MemStorage();
