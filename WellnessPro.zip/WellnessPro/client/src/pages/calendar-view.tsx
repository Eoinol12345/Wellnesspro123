import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import type { WellnessEntry } from "@shared/schema";

export default function CalendarView() {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const { data: entries } = useQuery<WellnessEntry[]>({
    queryKey: ["/api/wellness-entries"],
    queryFn: async () => {
      const response = await fetch("/api/wellness-entries?limit=90");
      return response.json();
    },
  });

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getEntryForDate = (date: Date | null) => {
    if (!date || !entries) return null;
    return entries.find(entry => {
      const entryDate = new Date(entry.timestamp);
      return entryDate.toDateString() === date.toDateString();
    });
  };

  const getDateColor = (entry: WellnessEntry | null) => {
    if (!entry) return "bg-gray-100 text-gray-400";
    
    // Priority: Injury > High Fatigue > Low Sleep > Good
    if (entry.injuryStatus !== "none") return "bg-red-100 text-red-800 border-red-300";
    if (entry.fatigueLevel >= 4) return "bg-yellow-100 text-yellow-800 border-yellow-300";
    if (parseFloat(entry.sleepHours) < 7) return "bg-orange-100 text-orange-800 border-orange-300";
    return "bg-green-100 text-green-800 border-green-300";
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentDate(prev => {
      const newDate = new Date(prev);
      if (direction === 'prev') {
        newDate.setMonth(prev.getMonth() - 1);
      } else {
        newDate.setMonth(prev.getMonth() + 1);
      }
      return newDate;
    });
  };

  const days = getDaysInMonth(currentDate);
  const monthYear = currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Calendar */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Calendar className="mr-2 h-5 w-5 text-athletic-blue" />
                  Wellness Calendar
                </CardTitle>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigateMonth('prev')}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="font-medium text-lg px-4">{monthYear}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigateMonth('next')}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-1 mb-4">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                  <div key={day} className="text-center text-sm font-medium text-gray-600 p-2">
                    {day}
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-7 gap-1">
                {days.map((date, index) => {
                  const entry = getEntryForDate(date);
                  return (
                    <div
                      key={index}
                      className={`
                        aspect-square p-2 text-sm rounded-lg border-2 transition-colors
                        ${date ? getDateColor(entry) : 'bg-gray-50'}
                        ${date && !entry ? 'border-dashed border-gray-300' : 'border-solid'}
                      `}
                    >
                      {date && (
                        <div className="flex flex-col h-full">
                          <div className="font-medium">{date.getDate()}</div>
                          {entry && (
                            <div className="flex-1 flex flex-col justify-center text-xs space-y-1">
                              <div>💤 {entry.sleepHours}h</div>
                              <div>⚡ {entry.fatigueLevel}/5</div>
                              {entry.sessionType !== "none" && (
                                <div>🏃 {entry.sessionType}</div>
                              )}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Legend and Stats */}
        <div className="space-y-6">
          {/* Legend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Legend</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-green-100 border-2 border-green-300 rounded mr-2"></div>
                <span className="text-sm">Good Day</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-orange-100 border-2 border-orange-300 rounded mr-2"></div>
                <span className="text-sm">Low Sleep (&lt;7h)</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-100 border-2 border-yellow-300 rounded mr-2"></div>
                <span className="text-sm">High Fatigue (4-5)</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-red-100 border-2 border-red-300 rounded mr-2"></div>
                <span className="text-sm">Injury Present</span>
              </div>
              <div className="flex items-center">
                <div className="w-4 h-4 bg-gray-100 border-2 border-gray-300 border-dashed rounded mr-2"></div>
                <span className="text-sm">No Data</span>
              </div>
            </CardContent>
          </Card>

          {/* Monthly Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Monthly Overview</CardTitle>
            </CardHeader>
            <CardContent>
              {entries && entries.length > 0 ? (
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Entries</span>
                    <span className="font-medium">
                      {entries.filter(e => {
                        const entryDate = new Date(e.timestamp);
                        return entryDate.getMonth() === currentDate.getMonth() &&
                               entryDate.getFullYear() === currentDate.getFullYear();
                      }).length} days
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Avg Sleep</span>
                    <span className="font-medium">
                      {(entries.reduce((sum, e) => sum + parseFloat(e.sleepHours), 0) / entries.length).toFixed(1)}h
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Training Days</span>
                    <span className="font-medium">
                      {entries.filter(e => e.sessionType !== "none").length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Good Days</span>
                    <Badge className="bg-green-100 text-green-800">
                      {entries.filter(e => 
                        e.injuryStatus === "none" && 
                        e.fatigueLevel <= 3 && 
                        parseFloat(e.sleepHours) >= 7
                      ).length}
                    </Badge>
                  </div>
                </div>
              ) : (
                <div className="text-sm text-gray-500">
                  No data available for this month
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}