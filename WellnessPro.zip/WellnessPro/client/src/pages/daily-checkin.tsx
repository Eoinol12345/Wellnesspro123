import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertWellnessEntrySchema, type InsertWellnessEntry, type WellnessEntry } from "@shared/schema";
import { Bed, Battery, Gauge, Dumbbell, Heart, Save, Zap, RotateCcw, Lightbulb } from "lucide-react";

export default function DailyCheckin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [sleepHours, setSleepHours] = useState([8]);
  const [rpe, setRpe] = useState([6]);
  const [fatigueLevel, setFatigueLevel] = useState(3);
  const [injuryStatus, setInjuryStatus] = useState("none");
  const [showAutoFill, setShowAutoFill] = useState(false);

  // Fetch last entry for auto-fill
  const { data: lastEntry } = useQuery<WellnessEntry | null>({
    queryKey: ["/api/wellness-entries/last"],
  });

  // Fetch energy score
  const { data: energyScore } = useQuery<{
    score: number | null;
    status: string;
    breakdown?: { sleep: number; fatigue: number; rpe: number };
  }>({
    queryKey: ["/api/analytics/energy-score"],
  });

  // Fetch recommendations
  const { data: recommendations } = useQuery<Array<{
    type: string;
    title: string;
    description: string;
    priority: string;
  }>>({
    queryKey: ["/api/analytics/recommendations"],
  });

  useEffect(() => {
    if (lastEntry) {
      setShowAutoFill(true);
    }
  }, [lastEntry]);

  const form = useForm<InsertWellnessEntry>({
    resolver: zodResolver(insertWellnessEntrySchema),
    defaultValues: {
      sleepHours: 8,
      fatigueLevel: 3,
      rpe: 6,
      sessionType: "none",
      injuryStatus: "none",
    },
  });

  const createEntryMutation = useMutation({
    mutationFn: async (data: InsertWellnessEntry) => {
      const response = await apiRequest("POST", "/api/wellness-entries", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Daily check-in saved successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/wellness-entries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/energy-score"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/recommendations"] });
      form.reset();
      setSleepHours([8]);
      setRpe([6]);
      setFatigueLevel(3);
      setInjuryStatus("none");
      setShowAutoFill(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save check-in. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAutoFill = () => {
    if (lastEntry) {
      setSleepHours([parseFloat(lastEntry.sleepHours)]);
      setRpe([lastEntry.rpe]);
      setFatigueLevel(lastEntry.fatigueLevel);
      setInjuryStatus(lastEntry.injuryStatus as any);
      form.setValue("sleepHours", parseFloat(lastEntry.sleepHours));
      form.setValue("fatigueLevel", lastEntry.fatigueLevel);
      form.setValue("rpe", lastEntry.rpe);
      form.setValue("sessionType", lastEntry.sessionType as any);
      form.setValue("injuryStatus", lastEntry.injuryStatus as any);
      setShowAutoFill(false);
      
      toast({
        title: "Values filled",
        description: "Yesterday's values have been applied. Adjust as needed.",
      });
    }
  };

  const onSubmit = (data: InsertWellnessEntry) => {
    createEntryMutation.mutate({
      ...data,
      sleepHours: sleepHours[0],
      rpe: rpe[0],
      fatigueLevel,
      injuryStatus: injuryStatus as any,
    });
  };

  const getEnergyScoreColor = (score: number | null) => {
    if (!score) return "bg-gray-100 text-gray-800";
    if (score >= 80) return "bg-green-100 text-green-800";
    if (score >= 65) return "bg-blue-100 text-blue-800";
    if (score >= 50) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const FatigueButton = ({ value, isSelected, onClick }: { value: number; isSelected: boolean; onClick: () => void }) => (
    <button
      type="button"
      onClick={onClick}
      className={`w-12 h-12 rounded-lg border-2 text-sm font-medium transition-colors ${
        isSelected
          ? 'border-athletic-blue bg-athletic-blue text-white'
          : 'border-gray-300 text-gray-700 hover:border-athletic-blue'
      }`}
    >
      {value}
    </button>
  );

  const InjuryButton = ({ value, label, icon, isSelected, onClick, colorClass }: {
    value: string;
    label: string;
    icon: React.ReactNode;
    isSelected: boolean;
    onClick: () => void;
    colorClass: string;
  }) => (
    <button
      type="button"
      onClick={onClick}
      className={`p-3 border-2 rounded-lg text-sm font-medium transition-colors ${
        isSelected
          ? colorClass
          : 'border-gray-300 text-gray-700 hover:border-gray-400'
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Energy Score Card */}
        {energyScore && energyScore.score !== null && (
          <Card className="bg-gradient-to-r from-blue-50 to-green-50">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-energy-green" />
                Today's Energy Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-3xl font-bold text-gray-900">{energyScore.score}/100</div>
                  <Badge className={getEnergyScoreColor(energyScore.score)} variant="secondary">
                    {energyScore.status}
                  </Badge>
                </div>
                {energyScore.breakdown && (
                  <div className="text-sm text-gray-600 space-y-1">
                    <div>Sleep: {energyScore.breakdown.sleep}/35</div>
                    <div>Energy: {energyScore.breakdown.fatigue}/35</div>
                    <div>Recovery: {energyScore.breakdown.rpe}/30</div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Recommendations */}
        {recommendations && recommendations.length > 0 && (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center text-orange-800">
                <Lightbulb className="mr-2 h-5 w-5" />
                Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recommendations.map((rec, index) => (
                  <Alert key={index} className="border-orange-300">
                    <AlertDescription className="text-orange-800">
                      <strong>{rec.title}:</strong> {rec.description}
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Check-in Form */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm border border-gray-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-2xl font-bold text-gray-900">Daily Wellness Check-In</CardTitle>
                  {showAutoFill && lastEntry && (
                    <Button
                      onClick={handleAutoFill}
                      variant="outline"
                      size="sm"
                      className="text-athletic-blue"
                    >
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Use Yesterday's Values
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Sleep Hours */}
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  <Bed className="inline mr-2 h-4 w-4 text-indigo-500" />
                  Sleep Hours
                </Label>
                <div className="flex items-center space-x-4">
                  <Slider
                    value={sleepHours}
                    onValueChange={setSleepHours}
                    max={12}
                    min={0}
                    step={0.5}
                    className="flex-1"
                  />
                  <span className="w-16 text-right font-semibold text-gray-900">
                    {sleepHours[0]}h
                  </span>
                </div>
              </div>

              {/* Fatigue Level */}
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  <Battery className="inline mr-2 h-4 w-4 text-orange-500" />
                  Fatigue Level
                </Label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map((level) => (
                    <FatigueButton
                      key={level}
                      value={level}
                      isSelected={fatigueLevel === level}
                      onClick={() => setFatigueLevel(level)}
                    />
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-1">1 = Fresh, 5 = Exhausted</p>
              </div>

              {/* RPE */}
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  <Gauge className="inline mr-2 h-4 w-4 text-red-500" />
                  RPE (Rate of Perceived Exertion)
                </Label>
                <div className="flex items-center space-x-4">
                  <Slider
                    value={rpe}
                    onValueChange={setRpe}
                    max={10}
                    min={1}
                    step={1}
                    className="flex-1"
                  />
                  <span className="w-16 text-right font-semibold text-gray-900">
                    {rpe[0]}/10
                  </span>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Very Easy</span>
                  <span>Maximal</span>
                </div>
              </div>

              {/* Session Type */}
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  <Dumbbell className="inline mr-2 h-4 w-4 text-green-500" />
                  Session Type
                </Label>
                <Select onValueChange={(value) => form.setValue("sessionType", value as any)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select session type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="pitch">Pitch Training</SelectItem>
                    <SelectItem value="gym">Gym Session</SelectItem>
                    <SelectItem value="match">Match</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Injury Status */}
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-2">
                  <Heart className="inline mr-2 h-4 w-4 text-red-500" />
                  Injury Status
                </Label>
                <div className="grid grid-cols-2 gap-3">
                  <InjuryButton
                    value="none"
                    label="None"
                    icon={<span className="mr-2">✓</span>}
                    isSelected={injuryStatus === "none"}
                    onClick={() => setInjuryStatus("none")}
                    colorClass="border-energy-green bg-green-50 text-energy-green"
                  />
                  <InjuryButton
                    value="minor"
                    label="Minor"
                    icon={<span className="mr-2">⚠</span>}
                    isSelected={injuryStatus === "minor"}
                    onClick={() => setInjuryStatus("minor")}
                    colorClass="border-energy-orange bg-orange-50 text-energy-orange"
                  />
                  <InjuryButton
                    value="moderate"
                    label="Moderate"
                    icon={<span className="mr-2">⚠</span>}
                    isSelected={injuryStatus === "moderate"}
                    onClick={() => setInjuryStatus("moderate")}
                    colorClass="border-energy-orange bg-orange-50 text-energy-orange"
                  />
                  <InjuryButton
                    value="serious"
                    label="Serious"
                    icon={<span className="mr-2">✕</span>}
                    isSelected={injuryStatus === "serious"}
                    onClick={() => setInjuryStatus("serious")}
                    colorClass="border-alert-red bg-red-50 text-alert-red"
                  />
                </div>
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                className="w-full bg-athletic-blue text-white hover:bg-blue-800 transition-colors"
                disabled={createEntryMutation.isPending}
              >
                <Save className="mr-2 h-4 w-4" />
                {createEntryMutation.isPending ? "Saving..." : "Save Today's Check-In"}
              </Button>
                </form>
              </CardContent>
            </Card>
          </div>
          
          {/* Sidebar with Tips */}
          <div className="space-y-4">
            {lastEntry && (
              <Card className="bg-blue-50 border-blue-200">
                <CardHeader>
                  <CardTitle className="text-blue-800 text-sm">Yesterday's Values</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-blue-700">
                  <div className="space-y-2">
                    <div>Sleep: {lastEntry.sleepHours}h</div>
                    <div>Fatigue: {lastEntry.fatigueLevel}/5</div>
                    <div>RPE: {lastEntry.rpe}/10</div>
                    <div>Session: {lastEntry.sessionType}</div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            <Card className="bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800 text-sm">Tips</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-green-700">
                <ul className="space-y-2">
                  <li>• Rate fatigue honestly to track recovery</li>
                  <li>• RPE measures how hard training felt</li>
                  <li>• Log entries consistently for better insights</li>
                  <li>• Sleep quality matters as much as quantity</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  );
}
