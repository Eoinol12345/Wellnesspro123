import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { TrendingUp, Bed, Battery, Gauge, Dumbbell, Clock, Users, Zap, ArrowUp, ArrowDown, Minus } from "lucide-react";
import { useEffect, useRef } from "react";
import { initSleepFatigueChart, initRpeChart } from "@/lib/chart-utils";
import type { WellnessEntry } from "@shared/schema";

interface DashboardStats {
  avgSleep: number;
  avgFatigue: number;
  avgRpe: number;
  totalTrainingLoad: number;
  weeklyStats: WellnessEntry[];
}

export default function Dashboard() {
  const sleepFatigueChartRef = useRef<HTMLCanvasElement>(null);
  const rpeChartRef = useRef<HTMLCanvasElement>(null);

  const { data: entries, isLoading: entriesLoading } = useQuery<WellnessEntry[]>({
    queryKey: ["/api/wellness-entries"],
    queryFn: async () => {
      const response = await fetch("/api/wellness-entries?limit=10");
      return response.json();
    },
  });

  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/wellness-entries/stats"],
    queryFn: async () => {
      const response = await fetch("/api/wellness-entries/stats");
      return response.json();
    },
  });

  // Weekly comparison data
  const { data: weeklyComparison } = useQuery<{
    thisWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
    lastWeek: { totalLoad: number; avgSleep: number; avgFatigue: number };
  }>({
    queryKey: ["/api/analytics/weekly-comparison"],
  });

  // Team stats
  const { data: teamStats } = useQuery<{
    memberCount: number;
    averages: { sleep: number; fatigue: number; rpe: number };
    yourRank: { sleep: number; fatigue: number; rpe: number };
  }>({
    queryKey: ["/api/team/stats"],
  });

  // Energy score
  const { data: energyScore } = useQuery<{
    score: number | null;
    status: string;
  }>({
    queryKey: ["/api/analytics/energy-score"],
  });

  // Patterns
  const { data: patterns } = useQuery<Array<{
    type: string;
    title: string;
    description: string;
    severity: string;
  }>>({
    queryKey: ["/api/analytics/patterns"],
  });

  useEffect(() => {
    if (entries && entries.length > 0 && sleepFatigueChartRef.current && rpeChartRef.current) {
      // Initialize charts with actual data
      const chartEntries = entries.slice(0, 7).reverse();
      initSleepFatigueChart(sleepFatigueChartRef.current, chartEntries);
      initRpeChart(rpeChartRef.current, chartEntries);
    }
  }, [entries]);

  const getComparisonIcon = (thisWeek: number, lastWeek: number) => {
    if (thisWeek > lastWeek) return <ArrowUp className="h-4 w-4 text-green-600" />;
    if (thisWeek < lastWeek) return <ArrowDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-600" />;
  };

  const getComparisonText = (thisWeek: number, lastWeek: number, unit: string = "") => {
    if (lastWeek === 0) return "No previous data";
    const percentage = Math.round(((thisWeek - lastWeek) / lastWeek) * 100);
    const direction = percentage > 0 ? "+" : "";
    return `${direction}${percentage}% vs last week`;
  };

  const getSessionTypeColor = (sessionType: string) => {
    switch (sessionType) {
      case "match":
        return "bg-green-100 text-green-800";
      case "gym":
        return "bg-blue-100 text-blue-800";
      case "pitch":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getFatigueColor = (fatigue: number) => {
    if (fatigue <= 2) return "bg-green-100 text-green-800";
    if (fatigue <= 3) return "bg-yellow-100 text-yellow-800";
    return "bg-red-100 text-red-800";
  };

  const getStatusColor = (entry: WellnessEntry) => {
    if (entry.injuryStatus !== "none") return "bg-red-100 text-red-800";
    if (entry.fatigueLevel >= 4) return "bg-yellow-100 text-yellow-800";
    return "bg-green-100 text-green-800";
  };

  const getStatusText = (entry: WellnessEntry) => {
    if (entry.injuryStatus !== "none") return "Injured";
    if (entry.fatigueLevel >= 4) return "Monitor";
    return "Good";
  };

  if (entriesLoading || statsLoading) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-96" />
      </main>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Energy Score & Pattern Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Energy Score */}
        {energyScore && energyScore.score !== null && (
          <Card className="bg-gradient-to-r from-green-50 to-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="mr-2 h-5 w-5 text-energy-green" />
                Current Energy Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-gray-900">{energyScore.score}/100</div>
              <div className="text-sm text-gray-600">{energyScore.status}</div>
            </CardContent>
          </Card>
        )}

        {/* Weekly Comparison */}
        {weeklyComparison && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="mr-2 h-5 w-5 text-athletic-blue" />
                This Week vs Last Week
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Training Load</span>
                  <div className="flex items-center">
                    {getComparisonIcon(weeklyComparison.thisWeek.totalLoad, weeklyComparison.lastWeek.totalLoad)}
                    <span className="text-sm font-medium ml-1">
                      {getComparisonText(weeklyComparison.thisWeek.totalLoad, weeklyComparison.lastWeek.totalLoad)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Avg Sleep</span>
                  <div className="flex items-center">
                    {getComparisonIcon(weeklyComparison.thisWeek.avgSleep, weeklyComparison.lastWeek.avgSleep)}
                    <span className="text-sm font-medium ml-1">
                      {getComparisonText(weeklyComparison.thisWeek.avgSleep, weeklyComparison.lastWeek.avgSleep)}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Team Comparison */}
        {teamStats && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="mr-2 h-5 w-5 text-green-600" />
                Team Comparison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 mb-3">{teamStats.memberCount} team members</div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Sleep vs Team</span>
                  <Badge variant={teamStats.yourRank.sleep >= 70 ? "default" : "secondary"}>
                    Top {100 - teamStats.yourRank.sleep}%
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm">Recovery vs Team</span>
                  <Badge variant={teamStats.yourRank.fatigue >= 70 ? "default" : "secondary"}>
                    Top {100 - teamStats.yourRank.fatigue}%
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Patterns Alert */}
      {patterns && patterns.length > 0 && (
        <div className="mb-6">
          <Alert className="border-orange-200 bg-orange-50">
            <AlertDescription>
              <strong>Patterns Detected:</strong> {patterns.map(p => p.description).join(" • ")}
            </AlertDescription>
          </Alert>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Sleep vs Fatigue Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="mr-2 h-5 w-5 text-athletic-blue" />
              Sleep vs Fatigue Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <canvas ref={sleepFatigueChartRef} width="400" height="200"></canvas>
          </CardContent>
        </Card>

        {/* RPE & Training Load Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Gauge className="mr-2 h-5 w-5 text-red-500" />
              RPE & Training Load
            </CardTitle>
          </CardHeader>
          <CardContent>
            <canvas ref={rpeChartRef} width="400" height="200"></canvas>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                <Bed className="h-5 w-5 text-indigo-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Avg Sleep</p>
                <p className="text-xl font-bold text-gray-900">
                  {stats ? `${stats.avgSleep}h` : "0h"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Battery className="h-5 w-5 text-orange-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Avg Fatigue</p>
                <p className="text-xl font-bold text-gray-900">
                  {stats ? `${stats.avgFatigue}/5` : "0/5"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <Gauge className="h-5 w-5 text-red-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Avg RPE</p>
                <p className="text-xl font-bold text-gray-900">
                  {stats ? `${stats.avgRpe}/10` : "0/10"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Dumbbell className="h-5 w-5 text-green-600" />
              </div>
              <div className="ml-3">
                <p className="text-sm font-medium text-gray-600">Training Load</p>
                <p className="text-xl font-bold text-gray-900">
                  {stats ? stats.totalTrainingLoad : 0}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Entries Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Clock className="mr-2 h-5 w-5 text-gray-600" />
            Recent Entries
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!entries || entries.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No wellness entries found. Start by creating your first daily check-in!
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Sleep</TableHead>
                  <TableHead>Fatigue</TableHead>
                  <TableHead>RPE</TableHead>
                  <TableHead>Session</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell className="font-medium">
                      {new Date(entry.timestamp).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric'
                      })}
                    </TableCell>
                    <TableCell>{entry.sleepHours}h</TableCell>
                    <TableCell>
                      <Badge className={getFatigueColor(entry.fatigueLevel)}>
                        {entry.fatigueLevel}/5
                      </Badge>
                    </TableCell>
                    <TableCell>{entry.rpe}/10</TableCell>
                    <TableCell>
                      <Badge className={getSessionTypeColor(entry.sessionType)}>
                        {entry.sessionType === "none" ? "Rest" : entry.sessionType}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(entry)}>
                        {getStatusText(entry)}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
