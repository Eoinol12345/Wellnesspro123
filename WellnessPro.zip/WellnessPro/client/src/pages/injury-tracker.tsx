import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { insertInjurySchema, type InsertInjury, type Injury } from "@shared/schema";
import { Plus, Activity, Calendar, MapPin, AlertTriangle, CheckCircle } from "lucide-react";

export default function InjuryTracker() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isAddingInjury, setIsAddingInjury] = useState(false);

  const form = useForm<InsertInjury>({
    resolver: zodResolver(insertInjurySchema),
    defaultValues: {
      type: "",
      location: "",
      severity: "minor",
      description: "",
      dateOccurred: new Date(),
      isActive: true,
    },
  });

  const { data: injuries, isLoading } = useQuery<Injury[]>({
    queryKey: ["/api/injuries"],
  });

  const createInjuryMutation = useMutation({
    mutationFn: async (data: InsertInjury) => {
      const response = await apiRequest("POST", "/api/injuries", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Injury logged successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/injuries"] });
      form.reset();
      setIsAddingInjury(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to log injury. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateInjuryMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Injury> }) => {
      const response = await apiRequest("PATCH", `/api/injuries/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Injury updated successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/injuries"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update injury.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertInjury) => {
    createInjuryMutation.mutate(data);
  };

  const markResolved = (injury: Injury) => {
    updateInjuryMutation.mutate({
      id: injury.id,
      updates: {
        isActive: false,
        dateResolved: new Date(),
      },
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "minor":
        return "bg-yellow-100 text-yellow-800";
      case "moderate":
        return "bg-orange-100 text-orange-800";
      case "serious":
        return "bg-red-100 text-red-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getInjuryTypeIcon = (type: string) => {
    if (type.toLowerCase().includes("muscle")) return "💪";
    if (type.toLowerCase().includes("joint")) return "🦴";
    if (type.toLowerCase().includes("impact")) return "💥";
    return "🩹";
  };

  const activeInjuries = injuries?.filter(i => i.isActive) || [];
  const resolvedInjuries = injuries?.filter(i => !i.isActive) || [];

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Injuries */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center">
                  <Activity className="mr-2 h-5 w-5 text-red-500" />
                  Active Injuries ({activeInjuries.length})
                </CardTitle>
                <Dialog open={isAddingInjury} onOpenChange={setIsAddingInjury}>
                  <DialogTrigger asChild>
                    <Button size="sm">
                      <Plus className="mr-2 h-4 w-4" />
                      Log Injury
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Log New Injury</DialogTitle>
                    </DialogHeader>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select injury type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="muscle">Muscle</SelectItem>
                                  <SelectItem value="joint">Joint</SelectItem>
                                  <SelectItem value="impact">Impact</SelectItem>
                                  <SelectItem value="overuse">Overuse</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Location</FormLabel>
                              <FormControl>
                                <Input placeholder="e.g., hamstring, knee, ankle" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="severity"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Severity</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="minor">Minor</SelectItem>
                                  <SelectItem value="moderate">Moderate</SelectItem>
                                  <SelectItem value="serious">Serious</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="dateOccurred"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Date Occurred</FormLabel>
                              <FormControl>
                                <Input
                                  type="date"
                                  {...field}
                                  value={field.value ? new Date(field.value).toISOString().split('T')[0] : ''}
                                  onChange={(e) => field.onChange(new Date(e.target.value))}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Description (Optional)</FormLabel>
                              <FormControl>
                                <Textarea
                                  placeholder="Additional details about the injury..."
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="flex justify-end space-x-2">
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => setIsAddingInjury(false)}
                          >
                            Cancel
                          </Button>
                          <Button
                            type="submit"
                            disabled={createInjuryMutation.isPending}
                          >
                            {createInjuryMutation.isPending ? "Logging..." : "Log Injury"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              {activeInjuries.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <CheckCircle className="mx-auto h-12 w-12 text-green-500 mb-4" />
                  <p className="text-lg font-medium">No active injuries</p>
                  <p className="text-sm">You're injury-free! Keep up the good work.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {activeInjuries.map((injury) => (
                    <div
                      key={injury.id}
                      className="border rounded-lg p-4 bg-red-50 border-red-200"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-3">
                          <div className="text-2xl">{getInjuryTypeIcon(injury.type)}</div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-medium text-gray-900">
                                {injury.type} - {injury.location}
                              </h3>
                              <Badge className={getSeverityColor(injury.severity)}>
                                {injury.severity}
                              </Badge>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                              <div className="flex items-center">
                                <Calendar className="mr-1 h-3 w-3" />
                                {new Date(injury.dateOccurred).toLocaleDateString()}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="mr-1 h-3 w-3" />
                                {injury.location}
                              </div>
                            </div>
                            {injury.description && (
                              <p className="text-sm text-gray-700 mt-2">{injury.description}</p>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => markResolved(injury)}
                          disabled={updateInjuryMutation.isPending}
                        >
                          Mark Resolved
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Injury History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="mr-2 h-5 w-5 text-green-500" />
                Injury History
              </CardTitle>
            </CardHeader>
            <CardContent>
              {resolvedInjuries.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  <p>No injury history</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type & Location</TableHead>
                      <TableHead>Severity</TableHead>
                      <TableHead>Date Occurred</TableHead>
                      <TableHead>Date Resolved</TableHead>
                      <TableHead>Duration</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {resolvedInjuries.map((injury) => {
                      const duration = injury.dateResolved
                        ? Math.ceil(
                            (new Date(injury.dateResolved).getTime() - 
                             new Date(injury.dateOccurred).getTime()) / 
                            (1000 * 60 * 60 * 24)
                          )
                        : 0;
                      
                      return (
                        <TableRow key={injury.id}>
                          <TableCell>
                            <div className="flex items-center">
                              <span className="mr-2">{getInjuryTypeIcon(injury.type)}</span>
                              {injury.type} - {injury.location}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={getSeverityColor(injury.severity)}>
                              {injury.severity}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Date(injury.dateOccurred).toLocaleDateString()}
                          </TableCell>
                          <TableCell>
                            {injury.dateResolved 
                              ? new Date(injury.dateResolved).toLocaleDateString()
                              : "N/A"
                            }
                          </TableCell>
                          <TableCell>{duration} days</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Injury Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Active Injuries</span>
                  <span className="font-medium text-red-600">{activeInjuries.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Total Injuries</span>
                  <span className="font-medium">{injuries?.length || 0}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Resolved</span>
                  <span className="font-medium text-green-600">{resolvedInjuries.length}</span>
                </div>
                {resolvedInjuries.length > 0 && (
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Avg Recovery</span>
                    <span className="font-medium">
                      {Math.round(
                        resolvedInjuries.reduce((sum, injury) => {
                          if (!injury.dateResolved) return sum;
                          return sum + (
                            new Date(injury.dateResolved).getTime() - 
                            new Date(injury.dateOccurred).getTime()
                          ) / (1000 * 60 * 60 * 24);
                        }, 0) / resolvedInjuries.length
                      )} days
                    </span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {activeInjuries.length > 0 && (
            <Card className="border-orange-200 bg-orange-50">
              <CardHeader>
                <CardTitle className="flex items-center text-orange-800">
                  <AlertTriangle className="mr-2 h-5 w-5" />
                  Recovery Tips
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-orange-700">
                <ul className="space-y-2">
                  <li>• Follow RICE: Rest, Ice, Compression, Elevation</li>
                  <li>• Consult a healthcare professional</li>
                  <li>• Gradually return to activity</li>
                  <li>• Monitor pain levels during movement</li>
                  <li>• Consider physiotherapy if needed</li>
                </ul>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </main>
  );
}