import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChart3, Lightbulb, AlertTriangle, Trophy, Download, FileText } from "lucide-react";
import { useEffect, useRef } from "react";
import { initWeeklyLoadChart } from "@/lib/chart-utils";
import type { WellnessEntry } from "@shared/schema";

interface WeeklyStats {
  avgSleep: number;
  avgFatigue: number;
  avgRpe: number;
  totalTrainingLoad: number;
  weeklyStats: WellnessEntry[];
}

export default function WeeklySummary() {
  const weeklyLoadChartRef = useRef<HTMLCanvasElement>(null);

  const { data: stats, isLoading } = useQuery<WeeklyStats>({
    queryKey: ["/api/wellness-entries/stats"],
  });

  const { data: entries } = useQuery<WellnessEntry[]>({
    queryKey: ["/api/wellness-entries"],
    queryFn: async () => {
      const response = await fetch("/api/wellness-entries?limit=7");
      return response.json();
    },
  });

  useEffect(() => {
    if (entries && entries.length > 0 && weeklyLoadChartRef.current) {
      initWeeklyLoadChart(weeklyLoadChartRef.current, entries.slice(0, 7).reverse());
    }
  }, [entries]);

  const handleExportWeekly = async () => {
    try {
      const response = await fetch('/api/wellness-entries/export');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'weekly-wellness-data.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const generateInsights = (entries: WellnessEntry[]) => {
    if (!entries || entries.length === 0) return [];

    const insights = [];
    const trainingSessions = entries.filter(e => e.sessionType !== "none");
    const matches = entries.filter(e => e.sessionType === "match");
    const highFatigueDays = entries.filter(e => e.fatigueLevel >= 4);
    const bestRecoveryDay = entries.reduce((best, current) => 
      (parseFloat(current.sleepHours) + (6 - current.fatigueLevel)) > 
      (parseFloat(best.sleepHours) + (6 - best.fatigueLevel)) ? current : best
    );

    if (trainingSessions.length > 0) {
      const highestRpe = Math.max(...trainingSessions.map(e => e.rpe));
      const highestRpeDay = trainingSessions.find(e => e.rpe === highestRpe);
      insights.push(`You trained ${trainingSessions.length} times this week, with your highest intensity on ${new Date(highestRpeDay!.timestamp).toLocaleDateString('en-US', { weekday: 'long' })} (RPE: ${highestRpe}/10)`);
    }

    insights.push(`Best recovery day was ${new Date(bestRecoveryDay.timestamp).toLocaleDateString('en-US', { weekday: 'long' })} with ${bestRecoveryDay.sleepHours} hours sleep and fatigue level of ${bestRecoveryDay.fatigueLevel}/5`);

    if (trainingSessions.length >= 3) {
      insights.push("Your training load peaked mid-week - consider lighter sessions towards weekend");
    }

    return insights;
  };

  const generateAlerts = (entries: WellnessEntry[]) => {
    if (!entries || entries.length === 0) return [];

    const alerts = [];
    const consecutiveHighFatigue = entries.slice(0, 3).every(e => e.fatigueLevel >= 4);
    const avgSleep = entries.reduce((sum, e) => sum + parseFloat(e.sleepHours), 0) / entries.length;

    if (consecutiveHighFatigue) {
      alerts.push({
        type: "error",
        title: "High Fatigue Alert",
        message: "Fatigue ≥4 for 3 consecutive days. Consider rest.",
      });
    }

    if (avgSleep < 7) {
      alerts.push({
        type: "warning",
        title: "Sleep Deficit",
        message: "Average sleep below 7h this week.",
      });
    }

    return alerts;
  };

  if (isLoading) {
    return (
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Skeleton className="h-96" />
            <Skeleton className="h-64" />
          </div>
          <div className="space-y-6">
            <Skeleton className="h-48" />
            <Skeleton className="h-48" />
            <Skeleton className="h-48" />
          </div>
        </div>
      </main>
    );
  }

  const insights = entries ? generateInsights(entries) : [];
  const alerts = entries ? generateAlerts(entries) : [];

  return (
    <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Stats */}
        <div className="lg:col-span-2 space-y-6">
          {/* Training Load Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="mr-2 h-5 w-5 text-athletic-blue" />
                This Week's Training Load
              </CardTitle>
            </CardHeader>
            <CardContent>
              <canvas ref={weeklyLoadChartRef} width="400" height="200"></canvas>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-2xl font-bold text-gray-900">
                    {stats ? stats.totalTrainingLoad : 0}
                  </p>
                  <p className="text-sm text-gray-600">Total Load</p>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <p className="text-2xl font-bold text-gray-900">
                    {stats && entries ? Math.round(stats.totalTrainingLoad / Math.max(entries.length, 1)) : 0}
                  </p>
                  <p className="text-sm text-gray-600">Daily Average</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Auto-Generated Insights */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lightbulb className="mr-2 h-5 w-5 text-orange-500" />
                Weekly Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              {insights.length === 0 ? (
                <p className="text-gray-500">No insights available. Add more wellness entries to see personalized insights.</p>
              ) : (
                <div className="space-y-3">
                  {insights.map((insight, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-energy-green rounded-full mt-2"></div>
                      <p className="text-sm text-gray-700">{insight}</p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Alerts & Recommendations */}
        <div className="space-y-6">
          {/* Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-red-500" />
                Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {alerts.length === 0 ? (
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm font-medium text-green-800">All Clear!</p>
                  <p className="text-xs text-green-700 mt-1">No wellness concerns detected.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {alerts.map((alert, index) => (
                    <div
                      key={index}
                      className={`p-3 border rounded-lg ${
                        alert.type === "error"
                          ? "bg-red-50 border-red-200"
                          : "bg-yellow-50 border-yellow-200"
                      }`}
                    >
                      <div className="flex items-center">
                        <AlertTriangle
                          className={`mr-2 h-4 w-4 ${
                            alert.type === "error" ? "text-red-500" : "text-yellow-500"
                          }`}
                        />
                        <p
                          className={`text-sm font-medium ${
                            alert.type === "error" ? "text-red-800" : "text-yellow-800"
                          }`}
                        >
                          {alert.title}
                        </p>
                      </div>
                      <p
                        className={`text-xs mt-1 ${
                          alert.type === "error" ? "text-red-700" : "text-yellow-700"
                        }`}
                      >
                        {alert.message}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Trophy className="mr-2 h-5 w-5 text-green-500" />
                Week at a Glance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Training Sessions</span>
                  <span className="font-semibold text-gray-900">
                    {entries ? entries.filter(e => e.sessionType !== "none").length : 0}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Matches Played</span>
                  <span className="font-semibold text-gray-900">
                    {entries ? entries.filter(e => e.sessionType === "match").length : 0}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Injury-Free Days</span>
                  <span className="font-semibold text-gray-900">
                    {entries ? `${entries.filter(e => e.injuryStatus === "none").length}/${entries.length}` : "0/0"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Recovery Quality</span>
                  <Badge className={
                    stats && stats.avgFatigue <= 2.5 
                      ? "bg-green-100 text-green-800"
                      : stats && stats.avgFatigue <= 3.5
                      ? "bg-yellow-100 text-yellow-800"
                      : "bg-red-100 text-red-800"
                  }>
                    {stats && stats.avgFatigue <= 2.5 ? "Good" : stats && stats.avgFatigue <= 3.5 ? "Fair" : "Poor"}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Export Options */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="mr-2 h-5 w-5 text-gray-600" />
                Export Data
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button
                  onClick={handleExportWeekly}
                  className="w-full bg-athletic-blue text-white hover:bg-blue-800 transition-colors"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Export This Week (CSV)
                </Button>
                <Button
                  onClick={handleExportWeekly}
                  variant="outline"
                  className="w-full"
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export All Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
