import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import DailyCheckin from "@/pages/daily-checkin";
import Dashboard from "@/pages/dashboard";
import WeeklySummary from "@/pages/weekly-summary";
import CalendarView from "@/pages/calendar-view";
import InjuryTracker from "@/pages/injury-tracker";
import Navigation from "@/components/navigation";

function Router() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <Switch>
        <Route path="/" component={DailyCheckin} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/weekly-summary" component={WeeklySummary} />
        <Route component={NotFound} />
      </Switch>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
