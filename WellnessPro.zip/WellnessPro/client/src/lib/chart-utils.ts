import { Chart, registerables } from 'chart.js';
import type { WellnessEntry } from '@shared/schema';

Chart.register(...registerables);

export const initSleepFatigueChart = (canvas: HTMLCanvasElement, entries: WellnessEntry[]) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Destroy existing chart if it exists
  const existingChart = Chart.getChart(canvas);
  if (existingChart) {
    existingChart.destroy();
  }

  const labels = entries.map(entry => 
    new Date(entry.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  );

  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        {
          label: 'Sleep Hours',
          data: entries.map(entry => parseFloat(entry.sleepHours)),
          borderColor: 'hsl(220, 91%, 42%)',
          backgroundColor: 'hsla(220, 91%, 42%, 0.1)',
          tension: 0.4,
          yAxisID: 'y'
        },
        {
          label: 'Fatigue Level',
          data: entries.map(entry => entry.fatigueLevel),
          borderColor: 'hsl(43, 96%, 56%)',
          backgroundColor: 'hsla(43, 96%, 56%, 0.1)',
          tension: 0.4,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          min: 0,
          max: 12,
          title: { display: true, text: 'Sleep Hours' }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          min: 1,
          max: 5,
          title: { display: true, text: 'Fatigue Level' }
        }
      }
    }
  });
};

export const initRpeChart = (canvas: HTMLCanvasElement, entries: WellnessEntry[]) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Destroy existing chart if it exists
  const existingChart = Chart.getChart(canvas);
  if (existingChart) {
    existingChart.destroy();
  }

  const labels = entries.map(entry => 
    new Date(entry.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  );

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'RPE',
          data: entries.map(entry => entry.rpe),
          backgroundColor: 'hsla(0, 84%, 60%, 0.8)',
          borderColor: 'hsl(0, 84%, 60%)',
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          max: 10,
          title: { display: true, text: 'RPE (1-10)' }
        }
      }
    }
  });
};

export const initWeeklyLoadChart = (canvas: HTMLCanvasElement, entries: WellnessEntry[]) => {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  // Destroy existing chart if it exists
  const existingChart = Chart.getChart(canvas);
  if (existingChart) {
    existingChart.destroy();
  }

  const sessionDurations = { none: 0, pitch: 90, gym: 60, match: 120 };
  
  const labels = entries.map(entry => 
    new Date(entry.timestamp).toLocaleDateString('en-US', { weekday: 'short' })
  );

  const trainingLoads = entries.map(entry => {
    const duration = sessionDurations[entry.sessionType] || 0;
    return entry.rpe * duration;
  });

  new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Training Load',
        data: trainingLoads,
        borderColor: 'hsl(160, 84%, 39%)',
        backgroundColor: 'hsla(160, 84%, 39%, 0.1)',
        tension: 0.4,
        fill: true
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: 'Training Load' }
        }
      }
    }
  });
};
