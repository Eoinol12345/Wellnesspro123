import type { WellnessEntry } from '@shared/schema';

export const exportToCSV = (entries: WellnessEntry[], filename: string = 'wellness-data.csv') => {
  const headers = ['Date', 'Sleep Hours', 'Fatigue Level', 'RPE', 'Session Type', 'Injury Status'];
  
  const csvContent = [
    headers.join(','),
    ...entries.map(entry => [
      new Date(entry.timestamp).toLocaleDateString(),
      entry.sleepHours,
      entry.fatigueLevel,
      entry.rpe,
      entry.sessionType,
      entry.injuryStatus
    ].join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const generateWeeklyReport = (entries: WellnessEntry[]): string => {
  if (entries.length === 0) return 'No data available for this week.';

  const avgSleep = entries.reduce((sum, entry) => sum + parseFloat(entry.sleepHours), 0) / entries.length;
  const avgFatigue = entries.reduce((sum, entry) => sum + entry.fatigueLevel, 0) / entries.length;
  const avgRpe = entries.reduce((sum, entry) => sum + entry.rpe, 0) / entries.length;
  
  const trainingSessions = entries.filter(e => e.sessionType !== 'none');
  const sessionDurations = { none: 0, pitch: 90, gym: 60, match: 120 };
  const totalTrainingLoad = entries.reduce((sum, entry) => {
    const duration = sessionDurations[entry.sessionType] || 0;
    return sum + (entry.rpe * duration);
  }, 0);

  return `
Weekly Wellness Report
======================

Summary:
- Average Sleep: ${avgSleep.toFixed(1)} hours
- Average Fatigue: ${avgFatigue.toFixed(1)}/5
- Average RPE: ${avgRpe.toFixed(1)}/10
- Total Training Load: ${totalTrainingLoad}
- Training Sessions: ${trainingSessions.length}

Daily Breakdown:
${entries.map(entry => 
  `${new Date(entry.timestamp).toLocaleDateString()}: Sleep ${entry.sleepHours}h, Fatigue ${entry.fatigueLevel}/5, RPE ${entry.rpe}/10, Session: ${entry.sessionType}`
).join('\n')}
`;
};
