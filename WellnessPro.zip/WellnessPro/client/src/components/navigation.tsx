import { Link, useLocation } from "wouter";
import { Zap, Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navigation() {
  const [location] = useLocation();
  
  const handleExportData = async () => {
    try {
      const response = await fetch('/api/wellness-entries/export');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'wellness-data.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const currentDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  return (
    <>
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-gradient-to-r from-athletic-blue to-energy-green rounded-lg flex items-center justify-center">
                <Zap className="text-white text-sm" size={16} />
              </div>
              <h1 className="text-xl font-bold text-gray-900">EnergyCheck</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Today: {currentDate}</span>
              <Button
                onClick={handleExportData}
                className="bg-energy-green text-white hover:bg-green-700 transition-colors"
                size="sm"
              >
                <Download className="mr-2 h-4 w-4" />
                Export CSV
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <Link href="/">
              <a className={`border-b-2 py-4 px-1 text-sm font-medium transition-colors ${
                location === '/' 
                  ? 'border-athletic-blue text-athletic-blue' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}>
                Daily Check-In
              </a>
            </Link>
            <Link href="/dashboard">
              <a className={`border-b-2 py-4 px-1 text-sm font-medium transition-colors ${
                location === '/dashboard' 
                  ? 'border-athletic-blue text-athletic-blue' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}>
                Dashboard
              </a>
            </Link>
            <Link href="/weekly-summary">
              <a className={`border-b-2 py-4 px-1 text-sm font-medium transition-colors ${
                location === '/weekly-summary' 
                  ? 'border-athletic-blue text-athletic-blue' 
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}>
                Weekly Summary
              </a>
            </Link>
          </div>
        </div>
      </nav>
    </>
  );
}
