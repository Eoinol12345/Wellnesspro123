# EnergyCheck - Wellness Monitoring Application

## Overview

EnergyCheck is a full-stack wellness monitoring application built for athletes to track their daily wellness metrics including sleep, fatigue levels, training intensity (RPE), session types, and injury status. The application provides data visualization, weekly summaries, and CSV export functionality.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Form Handling**: React Hook Form with Zod validation
- **Charts**: Chart.js for data visualization
- **Build Tool**: Vite with custom configuration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API design
- **Middleware**: Express middleware for request logging and error handling
- **Storage**: In-memory storage implementation with interface for future database integration
- **Development**: Vite integration for hot module replacement in development

### Database Design
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: Single `wellness_entries` table with fields:
  - `id`: Primary key (serial)
  - `sleepHours`: Decimal field for sleep duration
  - `fatigueLevel`: Integer (1-5 scale)
  - `rpe`: Integer (1-10 Rate of Perceived Exertion)
  - `sessionType`: Enum (none, pitch, gym, match)
  - `injuryStatus`: Enum (none, minor, moderate, serious)
  - `timestamp`: Automatic timestamp

## Key Components

### Frontend Components
1. **Daily Check-in Page**: Form-based wellness entry with sliders and dropdowns
2. **Dashboard**: Data visualization with charts showing trends
3. **Weekly Summary**: Aggregated statistics and insights
4. **Navigation**: Responsive navigation with export functionality
5. **UI Components**: Comprehensive shadcn/ui component library

### Backend Components
1. **Storage Layer**: Abstract interface with in-memory implementation
2. **API Routes**: CRUD operations for wellness entries
3. **Validation**: Zod schema validation for data integrity
4. **Error Handling**: Centralized error middleware

## Data Flow

1. **Entry Creation**: User fills daily check-in form → validation → API call → storage
2. **Data Retrieval**: Dashboard/summary pages → API queries → data aggregation → visualization
3. **Export**: User requests export → API generates CSV → download to client

## External Dependencies

### Core Dependencies
- **Database**: Neon Database (PostgreSQL) via `@neondatabase/serverless`
- **UI Framework**: Radix UI primitives for accessible components
- **Validation**: Zod for runtime type checking and validation
- **Charts**: Chart.js for data visualization
- **Date Handling**: date-fns for date utilities

### Development Dependencies
- **Build Tools**: Vite, esbuild for production builds
- **TypeScript**: Full TypeScript support across frontend and backend
- **Replit Integration**: Custom Vite plugins for Replit environment

## Deployment Strategy

### Development
- Single command setup: `npm run dev`
- Vite dev server with HMR for frontend
- tsx for TypeScript execution on backend
- Integrated development with Replit plugins

### Production
- Build process: `npm run build` (Vite build + esbuild bundle)
- Static frontend assets served from Express
- Node.js backend with compiled TypeScript
- Database migrations via Drizzle Kit

### Configuration
- Environment variables for database connection
- Separate client and server build outputs
- Path aliases for clean imports (`@/` for client, `@shared/` for shared types)

## Changelog

```
Changelog:
- June 29, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```