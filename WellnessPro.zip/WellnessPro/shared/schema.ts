import { pgTable, text, serial, integer, decimal, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const wellnessEntries = pgTable("wellness_entries", {
  id: serial("id").primaryKey(),
  sleepHours: decimal("sleep_hours", { precision: 3, scale: 1 }).notNull(),
  fatigueLevel: integer("fatigue_level").notNull(), // 1-5
  rpe: integer("rpe").notNull(), // 1-10
  sessionType: text("session_type").notNull(), // none, pitch, gym, match
  injuryStatus: text("injury_status").notNull(), // none, minor, moderate, serious
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const injuries = pgTable("injuries", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // muscle, joint, impact, etc.
  location: text("location").notNull(), // hamstring, knee, ankle, etc.
  severity: text("severity").notNull(), // minor, moderate, serious
  description: text("description"),
  dateOccurred: timestamp("date_occurred").notNull(),
  dateResolved: timestamp("date_resolved"),
  isActive: boolean("is_active").default(true).notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const userPreferences = pgTable("user_preferences", {
  id: serial("id").primaryKey(),
  reminderTime: text("reminder_time").default("20:00"), // 24h format
  enableReminders: boolean("enable_reminders").default(true),
  autoFillEnabled: boolean("auto_fill_enabled").default(true),
  teamId: text("team_id"),
  coachMode: boolean("coach_mode").default(false),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertWellnessEntrySchema = createInsertSchema(wellnessEntries).omit({
  id: true,
  timestamp: true,
}).extend({
  sleepHours: z.number().min(0).max(12),
  fatigueLevel: z.number().min(1).max(5),
  rpe: z.number().min(1).max(10),
  sessionType: z.enum(["none", "pitch", "gym", "match"]),
  injuryStatus: z.enum(["none", "minor", "moderate", "serious"]),
});

export const insertInjurySchema = createInsertSchema(injuries).omit({
  id: true,
  timestamp: true,
}).extend({
  type: z.string().min(1),
  location: z.string().min(1),
  severity: z.enum(["minor", "moderate", "serious"]),
  description: z.string().optional(),
  dateOccurred: z.date(),
  dateResolved: z.date().optional(),
  isActive: z.boolean().default(true),
});

export const insertUserPreferencesSchema = createInsertSchema(userPreferences).omit({
  id: true,
  timestamp: true,
});

export type InsertWellnessEntry = z.infer<typeof insertWellnessEntrySchema>;
export type WellnessEntry = typeof wellnessEntries.$inferSelect;
export type InsertInjury = z.infer<typeof insertInjurySchema>;
export type Injury = typeof injuries.$inferSelect;
export type InsertUserPreferences = z.infer<typeof insertUserPreferencesSchema>;
export type UserPreferences = typeof userPreferences.$inferSelect;
